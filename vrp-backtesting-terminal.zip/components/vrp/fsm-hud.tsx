"use client"

import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import { Wallet, TrendingUp, DollarSign } from "lucide-react"

type FsmState = "cash" | "long"

export function FsmHud() {
  const [state, setState] = React.useState<FsmState>("cash")

  const isCash = state === "cash"

  return (
    <section
      aria-label="Finite state machine live risk metrics"
      className="mx-auto grid w-full max-w-[1600px] grid-cols-1 gap-4 px-6 py-5 sm:grid-cols-3"
    >
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-xs font-medium text-muted-foreground">
            Active State
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-2">
          <Tooltip>
            <TooltipTrigger
              onClick={() => setState(isCash ? "long" : "cash")}
              className="w-fit cursor-pointer"
            >
              <Badge
                className={cn(
                  "font-mono-data text-xs tracking-wide",
                  isCash
                    ? "border-primary/30 bg-primary/15 text-primary"
                    : "border-amber-500/30 bg-amber-500/15 text-amber-400"
                )}
              >
                {isCash
                  ? "STATE 0: CASH (Short Variance)"
                  : "STATE 1: LONG ASSET (Covered Call)"}
              </Badge>
            </TooltipTrigger>
            <TooltipContent>Click to simulate FSM transition</TooltipContent>
          </Tooltip>
          <p className="text-xs text-muted-foreground">
            {isCash
              ? "Hunting for VRP entry signal."
              : "Holding assigned shares, writing covered calls."}
          </p>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-xs font-medium text-muted-foreground">
            Cost Basis &amp; Capital
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <Wallet className="size-4 text-muted-foreground" />
            <span className="font-mono-data text-lg font-semibold tabular-nums text-foreground">
              $0.00
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            Current Cost Basis
          </p>
          <div className="mt-2 flex items-center gap-2">
            <DollarSign className="size-4 text-muted-foreground" />
            <span className="font-mono-data text-sm tabular-nums text-foreground">
              Deployed: $0
            </span>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-xs font-medium text-muted-foreground">
            Performance
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <TrendingUp className="size-4 text-primary" />
            <span className="font-mono-data text-lg font-semibold tabular-nums text-primary">
              +$14,250
            </span>
          </div>
          <p className="text-xs text-muted-foreground">Cumulative P&amp;L</p>
          <div className="mt-2 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Win Rate</span>
            <span className="font-mono-data text-sm tabular-nums text-foreground">
              82%
            </span>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
