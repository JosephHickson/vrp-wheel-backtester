import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { cn } from "@/lib/utils"
import { tradeLedger, tradeSpread } from "@/lib/vrp-data"

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
})

const outcomeColor: Record<string, string> = {
  win: "text-emerald-400",
  assigned: "text-amber-400",
  loss: "text-red-400",
}

export function TradeLedger() {
  return (
    <section className="mx-auto w-full max-w-[1600px] px-6 py-5">
      <Card className="bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-foreground">
            Trade Ledger &amp; VRP Monitor
          </CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          <div className="overflow-x-auto">
            <Table className="font-mono-data text-xs">
              <TableHeader>
                <TableRow className="border-border">
                  <TableHead className="text-left">Date</TableHead>
                  <TableHead className="text-right">Spot Price</TableHead>
                  <TableHead className="text-right">IV30</TableHead>
                  <TableHead className="text-right">RV20</TableHead>
                  <TableHead className="text-right">Spread (IV-RV)</TableHead>
                  <TableHead className="text-left">FSM Action</TableHead>
                  <TableHead className="text-right">Target Strike</TableHead>
                  <TableHead className="text-right">
                    Premium Collected
                  </TableHead>
                  <TableHead className="text-left">Outcome</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tradeLedger.map((row) => {
                  const spreadValue = tradeSpread(row)
                  const isHighSpread = spreadValue > 0.12
                  return (
                    <TableRow key={row.date} className="border-border">
                      <TableCell className="text-left tabular-nums text-foreground">
                        {row.date}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-foreground">
                        ${row.spot.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {row.iv30.toFixed(1)}%
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {row.rv20.toFixed(1)}%
                      </TableCell>
                      <TableCell
                        className={cn(
                          "text-right tabular-nums font-medium",
                          isHighSpread ? "text-emerald-400" : "text-foreground"
                        )}
                      >
                        {spreadValue.toFixed(3)}
                      </TableCell>
                      <TableCell className="text-left text-foreground">
                        {row.fsmAction}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-foreground">
                        ${row.targetStrike.toFixed(0)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-foreground">
                        {currency.format(row.premium)}
                      </TableCell>
                      <TableCell
                        className={cn(
                          "text-left font-medium",
                          outcomeColor[row.outcome]
                        )}
                      >
                        {row.outcomeLabel}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
