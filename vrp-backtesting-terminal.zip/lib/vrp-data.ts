export type TradeOutcome = "win" | "assigned" | "loss"

export interface TradeLedgerRow {
  date: string
  spot: number
  iv30: number
  rv20: number
  fsmAction: string
  targetStrike: number
  premium: number
  outcome: TradeOutcome
  outcomeLabel: string
}

function spread(iv30: number, rv20: number) {
  return Number(((iv30 - rv20) / 100).toFixed(3))
}

export const tradeLedger: TradeLedgerRow[] = [
  {
    date: "2024-06-03",
    spot: 1450.25,
    iv30: 68.4,
    rv20: 52.1,
    fsmAction: "SELL PUT",
    targetStrike: 1230,
    premium: 18450,
    outcome: "win",
    outcomeLabel: "WIN (PUT OTM)",
  },
  {
    date: "2024-07-15",
    spot: 1510.8,
    iv30: 71.2,
    rv20: 58.9,
    fsmAction: "SELL PUT",
    targetStrike: 1285,
    premium: 21200,
    outcome: "assigned",
    outcomeLabel: "ASSIGNED -> STATE 1",
  },
  {
    date: "2024-08-05",
    spot: 1395.1,
    iv30: 94.5,
    rv20: 61.3,
    fsmAction: "SELL CALL (COVERED)",
    targetStrike: 1450,
    premium: 32750,
    outcome: "win",
    outcomeLabel: "WIN (CALL OTM)",
  },
]

export function tradeSpread(row: TradeLedgerRow) {
  return spread(row.iv30, row.rv20)
}
