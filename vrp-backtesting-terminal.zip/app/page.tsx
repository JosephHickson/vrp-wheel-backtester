"use client"

import * as React from "react"
import { CalibrationBar } from "@/components/vrp/calibration-bar"
import { FsmHud } from "@/components/vrp/fsm-hud"
import { TradeLedger } from "@/components/vrp/trade-ledger"
import { ReplayEngine } from "@/components/vrp/replay-engine"

export default function Page() {
  const [ticker, setTicker] = React.useState("MSTR")

  return (
    <main className="flex min-h-screen flex-col bg-background text-foreground">
      <CalibrationBar ticker={ticker} onTickerChange={setTicker} />
      <div className="flex-1 pb-4">
        <FsmHud />
        <TradeLedger />
      </div>
      <ReplayEngine />
    </main>
  )
}
