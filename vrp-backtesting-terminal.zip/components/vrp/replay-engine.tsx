"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { Play, Pause, SkipForward, Zap } from "lucide-react"

const RANGE_START = new Date("2024-01-01").getTime()
const RANGE_END = Date.now()

function formatSimulatedDate(progress: number) {
  const timestamp = RANGE_START + (RANGE_END - RANGE_START) * (progress / 100)
  return new Date(timestamp).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  })
}

export function ReplayEngine() {
  const [isPlaying, setIsPlaying] = React.useState(false)
  const [progress, setProgress] = React.useState(100)
  const [speed, setSpeed] = React.useState<string[]>(["1x"])

  React.useEffect(() => {
    if (!isPlaying) return
    const multiplier = Number(speed[0]?.replace("x", "") ?? 1)
    const interval = setInterval(() => {
      setProgress((p) => Math.min(100, p + 0.1 * multiplier))
    }, 100)
    return () => clearInterval(interval)
  }, [isPlaying, speed])

  return (
    <div className="sticky bottom-0 z-40 border-t border-border bg-background">
      <div className="mx-auto flex max-w-[1600px] flex-col gap-3 px-6 py-3 sm:flex-row sm:items-center sm:gap-6">
        <div className="flex items-center gap-1.5">
          <Button
            variant={isPlaying ? "default" : "outline"}
            size="icon"
            aria-label="Play"
            onClick={() => setIsPlaying(true)}
          >
            <Play />
          </Button>
          <Button
            variant={!isPlaying ? "default" : "outline"}
            size="icon"
            aria-label="Pause"
            onClick={() => setIsPlaying(false)}
          >
            <Pause />
          </Button>
          <Button
            variant="outline"
            size="icon"
            aria-label="Step forward"
            onClick={() => {
              setIsPlaying(false)
              setProgress((p) => Math.min(100, p + 1))
            }}
          >
            <SkipForward />
          </Button>
        </div>

        <div className="flex flex-1 flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-muted-foreground">
              Jan 2024
            </span>
            <span className="font-mono-data text-xs font-medium tabular-nums text-foreground">
              Simulating: {formatSimulatedDate(progress)}
            </span>
            <span className="text-[11px] text-muted-foreground">Present</span>
          </div>
          <Slider
            value={[progress]}
            onValueChange={(v) => setProgress((v as number[])[0])}
            min={0}
            max={100}
            step={0.1}
          />
        </div>

        <div className="flex items-center gap-3">
          <ToggleGroup
            value={speed}
            onValueChange={(v) => v.length > 0 && setSpeed(v as string[])}
            variant="outline"
            spacing={0}
            aria-label="Playback speed"
          >
            {["1x", "5x", "10x"].map((s) => (
              <ToggleGroupItem
                key={s}
                value={s}
                className="font-mono-data text-xs"
              >
                {s}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>

          <Button
            variant="outline"
            size="sm"
            className="font-mono-data text-xs"
            onClick={() => {
              const spike = new Date("2024-08-05").getTime()
              setProgress(
                ((spike - RANGE_START) / (RANGE_END - RANGE_START)) * 100
              )
            }}
          >
            <Zap data-icon="inline-start" />
            Jump to Vol Spike (Aug 2024)
          </Button>
        </div>
      </div>
    </div>
  )
}
