"use client"

import * as React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { Separator } from "@/components/ui/separator"
import { Activity } from "lucide-react"

const TENORS = ["7d", "14d", "21d", "45d"] as const

export function CalibrationBar({
  ticker,
  onTickerChange,
}: {
  ticker: string
  onTickerChange: (ticker: string) => void
}) {
  const [vrpHurdle, setVrpHurdle] = React.useState(0.12)
  const [otmCushion, setOtmCushion] = React.useState(15)
  const [tenor, setTenor] = React.useState<string[]>(["21d"])

  return (
    <header className="border-b border-border bg-background">
      <div className="mx-auto flex max-w-[1600px] flex-col gap-4 px-6 py-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-md border border-border bg-card text-primary">
              <Activity className="size-4" />
            </div>
            <div>
              <h1 className="font-mono-data text-sm font-semibold tracking-wide text-foreground sm:text-base">
                VRP ENGINE // MSTU &amp; MSTR HIGH-BETA PROXY
              </h1>
              <p className="text-xs text-muted-foreground">
                Volatility Risk Premium &amp; Wheel State Machine Backtester
              </p>
            </div>
          </div>

          <ToggleGroup
            value={[ticker]}
            onValueChange={(v) => v[0] && onTickerChange(v[0])}
            variant="outline"
            spacing={0}
            aria-label="Ticker selection"
          >
            <ToggleGroupItem value="MSTR" className="font-mono-data text-xs">
              MSTR (Proxy Backtest)
            </ToggleGroupItem>
            <ToggleGroupItem value="MSTU" className="font-mono-data text-xs">
              MSTU (Live Execution)
            </ToggleGroupItem>
          </ToggleGroup>
        </div>

        <Card className="bg-card">
          <CardContent className="flex flex-col gap-6 py-4 sm:flex-row sm:items-center sm:gap-8">
            <div className="flex min-w-48 flex-1 flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">
                  Min VRP Hurdle
                </span>
                <span className="font-mono-data text-xs tabular-nums text-foreground">
                  {(Number(Array.isArray(vrpHurdle) ? vrpHurdle[0] : vrpHurdle) || 0.12).toFixed(2)} Spread
                </span>
              </div>
              <Slider
                value={[vrpHurdle]}
                onValueChange={(v) => setVrpHurdle((v as number[])[0])}
                min={0}
                max={0.3}
                step={0.01}
              />
            </div>

            <Separator orientation="vertical" className="hidden h-10 sm:block" />

            <div className="flex min-w-48 flex-1 flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">
                  Target OTM Cushion
                </span>
                <span className="font-mono-data text-xs tabular-nums text-foreground">
                  {otmCushion}% OTM
                </span>
              </div>
              <Slider
                value={[otmCushion]}
                onValueChange={(v) => setOtmCushion((v as number[])[0])}
                min={0}
                max={30}
                step={1}
              />
            </div>

            <Separator orientation="vertical" className="hidden h-10 sm:block" />

            <div className="flex flex-col gap-2">
              <span className="text-xs font-medium text-muted-foreground">
                Contract Tenor
              </span>
              <ToggleGroup
                value={tenor}
                onValueChange={(v) => v.length > 0 && setTenor(v as string[])}
                variant="outline"
                spacing={0}
                aria-label="Contract tenor"
              >
                {TENORS.map((t) => (
                  <ToggleGroupItem
                    key={t}
                    value={t}
                    className="font-mono-data text-xs"
                  >
                    {t}
                  </ToggleGroupItem>
                ))}
              </ToggleGroup>
            </div>
          </CardContent>
        </Card>
      </div>
    </header>
  )
}
